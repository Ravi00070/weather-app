// main.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import './provider/weather_provider.dart';
import './screens/home_screen.dart';
import './screens/seven_day_forecast_detail_screen.dart';

void main() {
  runApp(
    MyApp(),
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => WeatherProvider(),
      child: MaterialApp(
        title: 'Flutter Weather',
        debugShowCheckedModeBanner: false,
        theme: _appTheme,
        home: HomeScreen(),
        onGenerateRoute: _onGenerateRoute,
      ),
    );
  }
}

ThemeData _appTheme = ThemeData(
  appBarTheme: AppBarTheme(
    backgroundColor: Colors.white,
    iconTheme: IconThemeData(color: Colors.blue),
    elevation: 0,
  ),
  scaffoldBackgroundColor: Colors.white,
  primaryColor: Colors.blue,
  visualDensity: VisualDensity.adaptivePlatformDensity,
  colorScheme: ColorScheme.fromSwatch().copyWith(secondary: Colors.white),
);

Route<dynamic> _onGenerateRoute(RouteSettings settings) {
  final arguments = settings.arguments;
  if (settings.name == SevenDayForecastDetail.routeName) {
    return PageRouteBuilder(
      settings: settings,
      pageBuilder: (_, __, ___) => SevenDayForecastDetail(
        initialIndex: arguments ?? 0,
      ),
      transitionsBuilder: (ctx, a, b, c) => CupertinoPageTransition(
        primaryRouteAnimation: a,
        secondaryRouteAnimation: b,
        linearTransition: false,
        child: c,
      ),
    );
  }
  // Unknown route
  return MaterialPageRoute(builder: (_) => HomeScreen());
}
