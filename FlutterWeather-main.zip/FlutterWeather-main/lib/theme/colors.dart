import 'package:flutter/material.dart';

const Color primaryBlue = Color(0xff81BCF7);
const Color backgroundBlue = Color(0xffCAE5FF);
const Color backgroundWhite = Color(0xffF2F8FF);
